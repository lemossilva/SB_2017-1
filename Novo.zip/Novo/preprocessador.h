#ifndef pre_processador
#define pre_processador
using namespace std;

bool pre_proc(ifstream &srce_file, fstream &no_comments);

#endif